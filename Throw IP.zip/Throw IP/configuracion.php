<?php
$server = "localhost";
$user = "root";
$pass = "";
$bd = "phplogin";
?>