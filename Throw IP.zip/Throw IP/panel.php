<?php
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <link rel="shortcut icon" href="img/ddos.ico" type="image/x-icon">
    <title>Throw IP | Inicio</title>

    <meta name="description" content="overview &amp; stats" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />


    <!-- bootstrap & fontawesome -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

    <!-- page specific plugin styles -->
    <link rel="stylesheet" href="assets/css/mierda.css" />
    <link rel="stylesheet" href="assets/css/safety.css" />
    <!-- text fonts -->
    <link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

    <!-- ace styles -->
    <link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
    <link rel="stylesheet" href="assets/css/ipstreeser.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/ace-skins.min.css" />
    <link rel="stylesheet" href="assets/css/ace-rtl.min.css" />
        <style> 
            body { 
                background-image: url("https://cdn.discordapp.com/attachments/839944402121392148/883457306061316096/code-matrix.gif"); 
                background-position: center 25%; 
                background-size: cover; 
            } 
        </style> 
</head>
  <body>
<nav><ul>
        <li><a href="admin.php">Inicio</a></li>
        <img src="./img/ddos1.png">
        <li><a href="panel.html">Panel De Control</a></li>
    </ul></nav>
</body>
    <head>
  <title>Throw IP | Control Panel</title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="img/ddo.isco" type="image/x-icon">
  <link rel="stylesheet" href="./css/ipstreeser.css">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="/pkgs/jquery/ui/1.10.3/themes/smoothness/jquery-ui.css" />
  <script type="text/javascript" src="/pkgs/jquery/jquery-1.9.1.min.js"></script>
  <script type="text/javascript" src="/pkgs/jquery/ui/1.10.3/js/jquery-ui.js"></script>
  <script type="text/javascript">

var running_tests = 0;
var remaining_bandwidth = 200;

function update_remaining_bandwidth(change) {
  var max_bandwidth = 200;
  running_tests--;
  remaining_bandwidth = Math.round(remaining_bandwidth + change);

  if (remaining_bandwidth > max_bandwidth) {
    remaining_bandwidth = max_bandwidth;
  }
  if (remaining_bandwidth >= 10) {
    $("#stresser_max_bandwidth").hide();
    $("#stresser_form").show();

    if (running_tests == 0) {
      $("#stop_all").html("");
    }
    if ($("#bandwidth_slider").slider("value") < 10) {
      if (remaining_bandwidth < 100) {
        $("#bandwidth").val((Math.floor(remaining_bandwidth / 10) * 10));
        $("#bandwidth_slider").slider("option", "value", (Math.floor(remaining_bandwidth / 10) * 10));
        $("#bandwidth_per_host").html((Math.round(((Math.floor(remaining_bandwidth / 10) * 10) / $(".host_container:visible").length) * 100) / 100).toFixed(2));
      } else {
        $("#bandwidth").val(100);
        $("#bandwidth_slider").slider("option", "value", 100);
        $("#bandwidth_per_host").html((Math.round((100 / $(".host_container:visible").length) * 100) / 100).toFixed(2));
      }
    } else {
      $("#bandwidth_per_host").html((Math.round(($("#bandwidth_slider").slider("value") / $(".host_container:visible").length) * 100) / 100).toFixed(2));
    }

    $("#stresser_info_box_remaining_bandwidth").html(remaining_bandwidth);
  }
}

jQuery.fn.extend({
  countdown: function(count, stop_id, details_id, bandwidth) {
    this.html("<span style=\"white-space:nowrap;\">" + count + " sec left</span>");
    this.width(this.width());
    var self = this.attr("id");

    var interval = setInterval(function() {
      document.getElementById(self).innerHTML = "<span style=\"white-space:nowrap;\">" + count + " sec left</span>";

      if (count == 0) {
        document.getElementById(self).innerHTML = "Completed";
        document.getElementById(stop_id).style.display = "none";
        document.getElementById(details_id).style.display = "block";
        update_remaining_bandwidth(bandwidth);
        clearInterval(interval);
      }

      count--;
    }, 1000);
  },
  add_host: function(host_container, error) {
    $(this).click(function(e) {
      e.preventDefault();
      var current_bandwidth = $("#bandwidth").val();

      if (current_bandwidth < (10 * ($(".host_container:visible").length + 1))) {
        current_bandwidth = (10 * ($(".host_container:visible").length + 1));
      }
      if (current_bandwidth <= remaining_bandwidth) {
        $(this).hide();
        $("#" + host_container).show();
        update_remaining_bandwidth(0);
      } else {
        $("#" + error).show().delay(10000).fadeOut();
      }
    });
  },
  prevent_double_submission: function() {
    $(this).on("submit", function(e) {
      if ($(this).data("submitted") === true) {
        e.preventDefault();
      } else {
        $(this).data("submitted", true);
      }
    });

    return this;
  }
});

$(function() {
  $("#add_host1").show();
  $("#stop_all_cell").width($("#stop_all_cell").width() + 1);
  $("#stop_all_cell").height($("#stop_all_cell").height() + 1);

  $("input:radio[name=method]").change(function() {
    hide_advanced();

    $("#drdos").hide();
    $("#rudy").hide();
    $("#slowloris").hide();

    if (this.value == "rudy" ||
      this.value == "arme") {
      $("#advanced_trigger").hide();
    } else {
      $("#advanced_trigger").show();
    }
    if (this.value == "rudy" ||
      this.value == "slowloris" ||
      this.value == "arme") {
      $("#port_valid_input").html(" (valid range: 1 - 65535; 80 = HTTP; 443 = HTTPS)");
      $("#bandwidth_label").html("Number of Connections:");
      $(".bandwidth_units").html("");
    } else {
      if (this.value == "drdos" && $("#drdos_protocol_chargen").is(":checked")) {
        $("#port_valid_input").html(" (valid range: 1025 - 65535; 0 = randomize each packet)");
      } else {
        $("#port_valid_input").html(" (valid range: 1 - 65535; 0 = randomize each packet)");
      }

      $("#bandwidth_label").html("Bandwidth:");
      $(".bandwidth_units").html("Mbps");
    }
    if (this.value == "drdos") {
      $("#drdos").show();
    } else if (this.value == "rudy") {
      $("#rudy").show();
    } else if (this.value == "slowloris") {
      $("#slowloris").show();
    }
  });
  $("input:checkbox[name='drdos_protocol[]']").change(function() {
    if ($("#drdos_protocol_chargen").is(":checked")) {
      $("#port_valid_input").html(" (valid range: 1025 - 65535; 0 = randomize each packet)");
    } else {
      $("#port_valid_input").html(" (valid range: 1 - 65535; 0 = randomize each packet)");
    }
  });

  $("#drdos_select_all").click(function(e) {
    e.preventDefault();
    $("input:checkbox[name='drdos_protocol[]']").prop("checked", true);
    $("#port_valid_input").html(" (valid range: 1025 - 65535; 0 = randomize each packet)");
    return false;
  });
  $("#drdos_select_none").click(function(e) {
    e.preventDefault();
    $("input:checkbox[name='drdos_protocol[]']").prop("checked", false);
    $("#port_valid_input").html(" (valid range: 1 - 65535; 0 = randomize each packet)");
    return false;
  });

  $("#advanced_trigger").click(function(e) {
    e.preventDefault();

    if ($("#advanced").is(":visible")) {
      hide_advanced();
    } else {
      show_advanced();
    }

    return false;
  });
  function hide_advanced() {
    $("#advanced_trigger").html("Advanced Options (Expand +)");
    $("#advanced").children().hide();
    $("#advanced").hide();
  }
  function show_advanced() {
    $("#advanced_trigger").html("Advanced Options (Collapse -)");
    $("#advanced").children().hide();
    $("#advanced").show();

    if ($("input:radio[name=method]:checked").val() == "drdos") {
      $("#response_size_container").show();
    } else if ($("input:radio[name=method]:checked").val() == "udp") {
      $("#udp_amplification_container").show();
      $("#packet_size_container").show();
      $("#randomize_ip_container").show();
    } else if ($("input:radio[name=method]:checked").val() == "udp_lag") {
      $("#flood_time_container").show();
      $("#recover_time_container").show();
      $("#packet_size_container").show();
      $("#randomize_ip_container").show();
    } else if ($("input:radio[name=method]:checked").val() == "syn") {
      $("#randomize_ip_container").show();

    } else if ($("input:radio[name=method]:checked").val() == "slowloris") {
      $("#slowloris_method_container").show();
      $("#conn_timeout_container").show();
      $("#tcp_timeout_container").show();
      $("#ssl_container").show();
    }
  }

  $("#port_valid_input").html(" (valid range: 1 - 65535; 0 = randomize each packet)");
  hide_advanced();

  $("#duration_slider").slider({
    range: "min",
    value: 60,
    min: 0,
    max: 3600,
    step: 5,
    slide: function(event, ui) {
      if (ui.value < 15) {
        $("#duration_slider").slider("option", "value", 15);
        $("#duration_sec").val(15);
        $("#duration_min").html("(" + (Math.round((15 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }
      if (ui.value > 300) {
        $("#duration_slider").slider("option", "value", 300);
        $("#duration_sec").val(300);
        $("#duration_min").html("(" + (Math.round((300 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }

      $("#duration_sec").val(ui.value);
      $("#duration_min").html("(" + (Math.round((ui.value / 60) * 100) / 100).toFixed(2) + "  Minutes)");
    }
  });

  $("#duration_sec").val($("#duration_slider").slider("value"));
  $("#duration_min").html("(" + (Math.round(($("#duration_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");

  $("#duration_sec").change(function() {
    if (this.value < 15) {
      this.value = 15;
    }
    if (this.value > 300) {
      this.value = 300;
    }

    $("#duration_slider").slider("option", "value", this.value);
    $("#duration_sec").val($("#duration_slider").slider("value"));
    $("#duration_min").html("(" + (Math.round(($("#duration_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");
  });

  $("#bandwidth_slider").slider({
    range: "min",
    value: 100,
    min: 0,
    max: 3000,
    step: 10,
    slide: function(event, ui) {
      if (ui.value < (10 * $(".host_container:visible").length)) {
        $("#bandwidth_slider").slider("option", "value", (10 * $(".host_container:visible").length));
        $("#bandwidth").val((10 * $(".host_container:visible").length));
        $("#bandwidth_per_host").html((Math.round(((10 * $(".host_container:visible").length) / $(".host_container:visible").length) * 100) / 100).toFixed(2));
        return false;
      }
      if (ui.value > (Math.floor(remaining_bandwidth / 10) * 10)) {
        $("#bandwidth_slider").slider("option", "value", (Math.floor(remaining_bandwidth / 10) * 10));
        $("#bandwidth").val((Math.floor(remaining_bandwidth / 10) * 10));
        $("#bandwidth_per_host").html((Math.round(((Math.floor(remaining_bandwidth / 10) * 10) / $(".host_container:visible").length) * 100) / 100).toFixed(2));
        return false;
      }

      $("#bandwidth").val(ui.value);
      $("#bandwidth_per_host").html((Math.round((ui.value / $(".host_container:visible").length) * 100) / 100).toFixed(2));
    }
  });

  $("#bandwidth").val($("#bandwidth_slider").slider("value"));
  $("#bandwidth_per_host").html((Math.round(($("#bandwidth_slider").slider("value") / $(".host_container:visible").length) * 100) / 100).toFixed(2));

  $("#bandwidth").change(function() {
    if (this.value < 10) {
      this.value = 10;
    }
    if (this.value > remaining_bandwidth) {
      this.value = remaining_bandwidth;
    }

    $("#bandwidth_slider").slider("option", "value", this.value);
    $("#bandwidth").val($("#bandwidth_slider").slider("value"));
    $("#bandwidth_per_host").html((Math.round(($("#bandwidth_slider").slider("value") / $(".host_container:visible").length) * 100) / 100).toFixed(2));
  });

  $("#packet_size_slider").slider({
    range: "min",
    value: 4096,
    min: 0,
    max: 65535,
    step: 1,
    slide: function(event, ui) {
      if (ui.value < 64) {
        $("#packet_size_slider").slider("option", "value", 64);
        $("#packet_size_b").val(64);
        $("#packet_size_kb").html("(" + (Math.round((64 / 1024) * 100) / 100).toFixed(2) + "  kB)");
        return false;
      }

      $("#packet_size_b").val(ui.value);
      $("#packet_size_kb").html("(" + (Math.round((ui.value / 1024) * 100) / 100).toFixed(2) + "  kB)");
      $("#udp_amplification").prop("checked", false);
    }
  });

  $("#packet_size_b").val($("#packet_size_slider").slider("value"));
  $("#packet_size_kb").html("(" + (Math.round(($("#packet_size_slider").slider("value") / 1024) * 100) / 100).toFixed(2) + "  kB)");

  $("#packet_size_b").change(function() {
    if (this.value < 64) {
      this.value = 64;
    }

    $("#packet_size_slider").slider("option", "value", this.value);
    $("#packet_size_b").val($("#packet_size_slider").slider("value"));
    $("#packet_size_kb").html("(" + (Math.round(($("#packet_size_slider").slider("value") / 1024) * 100) / 100).toFixed(2) + "  kB)");
  });

  $("#flood_time_slider").slider({
    range: "min",
    value: 2,
    min: 1,
    max: 300,
    step: 1,
    slide: function(event, ui) {
      if (ui.value < 1) {
        $("#flood_time_slider").slider("option", "value", 1);
        $("#flood_time_sec").val(1);
        $("#flood_time_min").html("(" + (Math.round((1 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }
      if (ui.value > 300) {
        $("#flood_time_slider").slider("option", "value", 300);
        $("#flood_time_sec").val(300);
        $("#flood_time_min").html("(" + (Math.round((300 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }

      $("#flood_time_sec").val(ui.value);
      $("#flood_time_min").html("(" + (Math.round((ui.value / 60) * 100) / 100).toFixed(2) + "  Minutes)");
    }
  });

  $("#flood_time_sec").val($("#flood_time_slider").slider("value"));
  $("#flood_time_min").html("(" + (Math.round(($("#flood_time_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");

  $("#flood_time_sec").change(function() {
    if (this.value < 1) {
      this.value = 1;
    }
    if (this.value > 300) {
      this.value = 300;
    }

    $("#flood_time_slider").slider("option", "value", this.value);
    $("#flood_time_sec").val($("#flood_time_slider").slider("value"));
    $("#flood_time_min").html("(" + (Math.round(($("#flood_time_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");
  });

  $("#recover_time_slider").slider({
    range: "min",
    value: 3,
    min: 1,
    max: 300,
    step: 1,
    slide: function(event, ui) {
      if (ui.value < 1) {
        $("#recover_time_slider").slider("option", "value", 1);
        $("#recover_time_sec").val(1);
        $("#recover_time_min").html("(" + (Math.round((1 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }
      if (ui.value > 300) {
        $("#recover_time_slider").slider("option", "value", 300);
        $("#recover_time_sec").val(300);
        $("#recover_time_min").html("(" + (Math.round((300 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }

      $("#recover_time_sec").val(ui.value);
      $("#recover_time_min").html("(" + (Math.round((ui.value / 60) * 100) / 100).toFixed(2) + "  Minutes)");
    }
  });

  $("#recover_time_sec").val($("#recover_time_slider").slider("value"));
  $("#recover_time_min").html("(" + (Math.round(($("#recover_time_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");

  $("#recover_time_sec").change(function() {
    if (this.value < 1) {
      this.value = 1;
    }
    if (this.value > 300) {
      this.value = 300;
    }

    $("#recover_time_slider").slider("option", "value", this.value);
    $("#recover_time_sec").val($("#recover_time_slider").slider("value"));
    $("#recover_time_min").html("(" + (Math.round(($("#recover_time_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");
  });

  $("#conn_timeout_slider").slider({
    range: "min",
    value: 30,
    min: 1,
    max: 300,
    step: 1,
    slide: function(event, ui) {
      if (ui.value < 1) {
        $("#conn_timeout_slider").slider("option", "value", 1);
        $("#conn_timeout_sec").val(1);
        $("#conn_timeout_min").html("(" + (Math.round((1 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }
      if (ui.value > 300) {
        $("#conn_timeout_slider").slider("option", "value", 300);
        $("#conn_timeout_sec").val(300);
        $("#conn_timeout_min").html("(" + (Math.round((300 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }

      $("#conn_timeout_sec").val(ui.value);
      $("#conn_timeout_min").html("(" + (Math.round((ui.value / 60) * 100) / 100).toFixed(2) + "  Minutes)");
    }
  });

  $("#conn_timeout_sec").val($("#conn_timeout_slider").slider("value"));
  $("#conn_timeout_min").html("(" + (Math.round(($("#conn_timeout_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");

  $("#conn_timeout_sec").change(function() {
    if (this.value < 1) {
      this.value = 1;
    }
    if (this.value > 300) {
      this.value = 300;
    }

    $("#conn_timeout_slider").slider("option", "value", this.value);
    $("#conn_timeout_sec").val($("#conn_timeout_slider").slider("value"));
    $("#conn_timeout_min").html("(" + (Math.round(($("#conn_timeout_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");
  });

  $("#tcp_timeout_slider").slider({
    range: "min",
    value: 5,
    min: 1,
    max: 60,
    step: 1,
    slide: function(event, ui) {
      if (ui.value < 1) {
        $("#tcp_timeout_slider").slider("option", "value", 1);
        $("#tcp_timeout_sec").val(1);
        $("#tcp_timeout_min").html("(" + (Math.round((1 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }
      if (ui.value > 60) {
        $("#tcp_timeout_slider").slider("option", "value", 60);
        $("#tcp_timeout_sec").val(60);
        $("#tcp_timeout_min").html("(" + (Math.round((60 / 60) * 100) / 100).toFixed(2) + "  Minutes)");
        return false;
      }

      $("#tcp_timeout_sec").val(ui.value);
      $("#tcp_timeout_min").html("(" + (Math.round((ui.value / 60) * 100) / 100).toFixed(2) + "  Minutes)");
    }
  });

  $("#tcp_timeout_sec").val($("#tcp_timeout_slider").slider("value"));
  $("#tcp_timeout_min").html("(" + (Math.round(($("#tcp_timeout_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");

  $("#tcp_timeout_sec").change(function() {
    if (this.value < 1) {
      this.value = 1;
    }
    if (this.value > 60) {
      this.value = 60;
    }

    $("#tcp_timeout_slider").slider("option", "value", this.value);
    $("#tcp_timeout_sec").val($("#tcp_timeout_slider").slider("value"));
    $("#tcp_timeout_min").html("(" + (Math.round(($("#tcp_timeout_slider").slider("value") / 60) * 100) / 100).toFixed(2) + "  Minutes)");
  });
});

  </script>
  <script type="text/javascript">
try {
  var jqueryIsLoaded = jQuery;
  jQueryIsLoaded = true;
}
catch (err) {
  jQueryIsLoaded = false;
}
if (jQueryIsLoaded) {
  main();
}
function main() {
  window.onload = function () {

$(".popup_close").click(function(e) {
  e.preventDefault();
  popup_hide_all();
    return false;
});
$("#popup_box").click(function(e) {
  if (e.target.id === "popup_box"){
    popup_hide_all();
  }
});
$(document).keyup(function(e) {
  if (e.keyCode == 27) {
    popup_hide_all();
  }
});

function popup_show_free_trial() {
  popup_show_container();
  $("#popup_box").children().hide();
  $("#popup_free_trial_box").fadeIn("slow");
}
function popup_show_container() {
  $("#popup_background:hidden").fadeIn("slow");
  $("#popup_container").css("display", "table");
  $("#popup_box").css("display", "table-cell");
}
function popup_hide_all() {
  $("#popup_background").fadeOut("slow");
  $("#popup_container").fadeOut("slow");
  $("#popup_box").fadeOut("slow");
  $("#popup_box").children().fadeOut("slow");
}

$("#add_host1").add_host("host_container2", "bandwidth_per_host_error1");
$("#add_host2").add_host("host_container3", "bandwidth_per_host_error2");
$("#add_host3").add_host("host_container4", "bandwidth_per_host_error3");
$("#add_host4").add_host("host_container5", "bandwidth_per_host_error4");
$("#add_host5").add_host("host_container6", "bandwidth_per_host_error5");
$("#add_host6").add_host("host_container7", "bandwidth_per_host_error6");
$("#add_host7").add_host("host_container8", "bandwidth_per_host_error7");
$("#add_host8").add_host("host_container9", "bandwidth_per_host_error8");
$("#add_host9").add_host("host_container10", "bandwidth_per_host_error9");
$("#add_host10").add_host("host_container11", "bandwidth_per_host_error10");
$("#add_host11").add_host("host_container12", "bandwidth_per_host_error11");
$("#add_host12").add_host("host_container13", "bandwidth_per_host_error12");
$("#add_host13").add_host("host_container14", "bandwidth_per_host_error13");
$("#add_host14").add_host("host_container15", "bandwidth_per_host_error14");
$("#add_host15").add_host("host_container16", "bandwidth_per_host_error15");
$("#add_host16").add_host("host_container17", "bandwidth_per_host_error16");
$("#add_host17").add_host("host_container18", "bandwidth_per_host_error17");
$("#add_host18").add_host("host_container19", "bandwidth_per_host_error18");
$("#add_host19").add_host("host_container20", "bandwidth_per_host_error19");
$("#add_host20").add_host("host_container21", "bandwidth_per_host_error20");
$("#add_host21").add_host("host_container22", "bandwidth_per_host_error21");
$("#add_host22").add_host("host_container23", "bandwidth_per_host_error22");
$("#add_host23").add_host("host_container24", "bandwidth_per_host_error23");
$("#add_host24").add_host("host_container25", "bandwidth_per_host_error24");
$("#add_host25").add_host("host_container26", "bandwidth_per_host_error25");
$("#add_host26").add_host("host_container27", "bandwidth_per_host_error26");
$("#add_host27").add_host("host_container28", "bandwidth_per_host_error27");
$("#add_host28").add_host("host_container29", "bandwidth_per_host_error28");
$("#add_host29").add_host("host_container30", "bandwidth_per_host_error29");
$("#add_host30").add_host("host_container31", "bandwidth_per_host_error30");
$("#add_host31").add_host("host_container32", "bandwidth_per_host_error31");
$("#launch_stress_test").prevent_double_submission();

  }
}
  </script>
    </head>
<body>
<div id="stresser_box" class="highlight_box">
  <h1 class="page_title centered" style="padding-bottom:0;">Throw IP</h1>
  <div id="stresser_max_bandwidth"  style="display:none;">
    <h2 class="page_title centered">You are currently at maximum bandwidth - please wait a few minutes and <a href="/index.php?page=stresser">click here</a>.</h2>
  </div>
  <div id="stresser_form" >
    <form id="launch_stress_test" action="" method="post">
      <input type="hidden" name="action" value="process" />
      <input type="hidden" name="token" value="kHcUvAKzhsaV4JZukPnjrfE4BnZmbmdg" />
      <p>
        <table border="0">
          <tr>
            <td valign="middle"><label>Method:</label></td>
            <td style="width:15px;"><td>
            <td valign="top">
              <div style="margin-left:50px;">
                &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="radio" id="method_drdos" name="method" value="drdos" checked /><label for="method_drdos">DRDoS</label><br />
                &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="radio" id="method_udp" name="method" value="udp" /><label for="method_udp">UDP</label><br />
                &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="radio" id="method_udp_lag" name="method" value="udp_lag" /><label for="method_udp_lag">UDP-Lag</label><br />
                &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="radio" id="method_syn" name="method" value="syn" /><label for="method_syn">SYN</label><br />
              </div>
            </td>
            <td style="width:15px;"><td>
            <td valign="top">
              </div>
            </td>
          </tr>
        </table>
      </p>
      <div id="drdos">
        <p>
<table border="0">
  <tr>
        </p>
      </div>

      <div class="host_container" id="host_container1">
        <p>
          <label for="host1">Host 1 (www.example.com or 1.1.1.1):</label><br />
          <input type="text" name="host1" id="host1" size="40" /> <a id="add_host1" class="btn btn_small btn_blue" href="#" style="display:none;">Add Host</a> <span id="bandwidth_per_host_error1" style="display:none;">Bandwidth for host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container2" style="display:none;">
        <p>
          <label for="host2">Host 2:</label><br />
          <input type="text" name="host2" id="host2" size="40" /> <a id="add_host2" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error2" style="display:none;">Bandwidth for host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container3" style="display:none;">
        <p>
          <label for="host3">Host 3:</label><br />
          <input type="text" name="host3" id="host3" size="40" /> <a id="add_host3" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error3" style="display:none;">Bandwidth for host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container4" style="display:none;">
        <p>
          <label for="host4">Host 4:</label><br />
          <input type="text" name="host4" id="host4" size="40" /> <a id="add_host4" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error4" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container5" style="display:none;">
        <p>
          <label for="host5">Host 5:</label><br />
          <input type="text" name="host5" id="host5" size="40" /> <a id="add_host5" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error5" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container6" style="display:none;">
        <p>
          <label for="host6">Host 6:</label><br />
          <input type="text" name="host6" id="host6" size="40" /> <a id="add_host6" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error6" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container7" style="display:none;">
        <p>
          <label for="host7">Host 7:</label><br />
          <input type="text" name="host7" id="host7" size="40" /> <a id="add_host7" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error7" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container8" style="display:none;">
        <p>
          <label for="host8">Host 8:</label><br />
          <input type="text" name="host8" id="host8" size="40" /> <a id="add_host8" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error8" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container9" style="display:none;">
        <p>
          <label for="host9">Host 9:</label><br />
          <input type="text" name="host9" id="host9" size="40" /> <a id="add_host9" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error9" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container10" style="display:none;">
        <p>
          <label for="host10">Host 10:</label><br />
          <input type="text" name="host10" id="host10" size="40" /> <a id="add_host10" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error10" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container11" style="display:none;">
        <p>
          <label for="host11">Host 11:</label><br />
          <input type="text" name="host11" id="host11" size="40" /> <a id="add_host11" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error11" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container12" style="display:none;">
        <p>
          <label for="host12">Host 12:</label><br />
          <input type="text" name="host12" id="host12" size="40" /> <a id="add_host12" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error12" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container13" style="display:none;">
        <p>
          <label for="host13">Host 13:</label><br />
          <input type="text" name="host13" id="host13" size="40" /> <a id="add_host13" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error13" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container14" style="display:none;">
        <p>
          <label for="host14">Host 14:</label><br />
          <input type="text" name="host14" id="host14" size="40" /> <a id="add_host14" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error14" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container15" style="display:none;">
        <p>
          <label for="host15">Host 15:</label><br />
          <input type="text" name="host15" id="host15" size="40" /> <a id="add_host15" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error15" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container16" style="display:none;">
        <p>
          <label for="host16">Host 16:</label><br />
          <input type="text" name="host16" id="host16" size="40" /> <a id="add_host16" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error16" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container17" style="display:none;">
        <p>
          <label for="host17">Host 17:</label><br />
          <input type="text" name="host17" id="host17" size="40" /> <a id="add_host17" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error17" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container18" style="display:none;">
        <p>
          <label for="host18">Host 18:</label><br />
          <input type="text" name="host18" id="host18" size="40" /> <a id="add_host18" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error18" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container19" style="display:none;">
        <p>
          <label for="host19">Host 19:</label><br />
          <input type="text" name="host19" id="host19" size="40" /> <a id="add_host19" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error19" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container20" style="display:none;">
        <p>
          <label for="host20">Host 20:</label><br />
          <input type="text" name="host20" id="host20" size="40" /> <a id="add_host20" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error20" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container21" style="display:none;">
        <p>
          <label for="host21">Host 21:</label><br />
          <input type="text" name="host21" id="host21" size="40" /> <a id="add_host21" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error21" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container22" style="display:none;">
        <p>
          <label for="host22">Host 22:</label><br />
          <input type="text" name="host22" id="host22" size="40" /> <a id="add_host22" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error22" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container23" style="display:none;">
        <p>
          <label for="host23">Host 23:</label><br />
          <input type="text" name="host23" id="host23" size="40" /> <a id="add_host23" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error23" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container24" style="display:none;">
        <p>
          <label for="host24">Host 24:</label><br />
          <input type="text" name="host24" id="host24" size="40" /> <a id="add_host24" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error24" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container25" style="display:none;">
        <p>
          <label for="host25">Host 25:</label><br />
          <input type="text" name="host25" id="host25" size="40" /> <a id="add_host25" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error25" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container26" style="display:none;">
        <p>
          <label for="host26">Host 26:</label><br />
          <input type="text" name="host26" id="host26" size="40" /> <a id="add_host26" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error26" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container27" style="display:none;">
        <p>
          <label for="host27">Host 27:</label><br />
          <input type="text" name="host27" id="host27" size="40" /> <a id="add_host27" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error27" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container28" style="display:none;">
        <p>
          <label for="host28">Host 28:</label><br />
          <input type="text" name="host28" id="host28" size="40" /> <a id="add_host28" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error28" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container29" style="display:none;">
        <p>
          <label for="host29">Host 29:</label><br />
          <input type="text" name="host29" id="host29" size="40" /> <a id="add_host29" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error29" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container30" style="display:none;">
        <p>
          <label for="host30">Host 30:</label><br />
          <input type="text" name="host30" id="host30" size="40" /> <a id="add_host30" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error30" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container31" style="display:none;">
        <p>
          <label for="host31">Host 31:</label><br />
          <input type="text" name="host31" id="host31" size="40" /> <a id="add_host31" class="btn btn_small btn_blue" href="#">Add Host</a> <span id="bandwidth_per_host_error31" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <div class="host_container" id="host_container32" style="display:none;">
        <p>
          <label for="host32">Host 32:</label><br />
          <input type="text" name="host32" id="host32" size="40" /> <span id="bandwidth_per_host_error32" style="display:none;">Bandwidth per host would be too low</span>
        </p>
      </div>

      <p>
        <label for="port">Port<span id="port_valid_input"></span>:</label><br />
        <input type="text" name="port" id="port" size="10" />
      </p>
      <div id="rudy" style="display:none;">
        <p>
          <label for="rudy_path">Form Path (/login.php):</label><br />
          <input type="text" name="rudy_path" id="rudy_path" size="40" />
        </p>
        <p>
          <label for="parameter">Form Parameter (login):</label><br />
          <input type="text" name="parameter" id="parameter" size="40" />
        </p>
      </div>
      <div id="slowloris" style="display:none;">
        <p>
          <label for="slowloris_path">File Path (/index.html):</label><br />
          <input type="text" name="slowloris_path" id="slowloris_path" size="40" />
        </p>
      </div>
      <p>
        <label for="duration_sec">Duration:</label>
        <input class="purchase_highlight" type="text" id="duration_sec" name="duration" size="3" /> Seconds <span id="duration_min"></span>
      </p>
      <div id="duration_slider" style="margin-left: 10px;margin-right: 10px;"></div>
      <p>
        <label id="bandwidth_label" for="bandwidth">Bandwidth:</label>
        <input class="purchase_highlight" type="text" id="bandwidth" name="bandwidth" size="3" /> <span class="bandwidth_units">Mbps</span> (<span id="bandwidth_per_host"></span> <span class="bandwidth_units">Mbps</span> for host)
      </p>
      <div id="bandwidth_slider" style="margin-left: 10px;margin-right: 10px;"></div>

      <p style="padding-top: 15px;">
        <a href="#" id="advanced_trigger" style="text-decoration: none;color: #3E9ECF;"></a>
      </p>
      <div id="advanced" style="display:none;">
        <div id="response_size_container">
          <p>
          </p>
        </div>
        <div id="flood_time_container">
          <p>
            <label for="flood_time_sec">Flood Time:</label>
            <input class="purchase_highlight" type="text" id="flood_time_sec" name="flood_time" size="3" /> Seconds <span id="flood_time_min"></span>
          </p>
          <div id="flood_time_slider" style="margin-left: 10px;margin-right: 10px;"></div>
        </div>
        <div id="recover_time_container">
          <p>
            <label for="recover_time_sec">Recover Time:</label>
            <input class="purchase_highlight" type="text" id="recover_time_sec" name="recover_time" size="3" /> Seconds <span id="recover_time_min"></span>
          </p>
          <div id="recover_time_slider" style="margin-left: 10px;margin-right: 10px;"></div>
        </div>
        <div id="udp_amplification_container">
          <p>
            <label for="udp_amplification">UDP Amplification (Overrides Packet Size):</label>
            <input class="purchase_highlight" type="checkbox" id="udp_amplification" name="udp_amplification" value="1" checked />
          </p>
        </div>
        <div id="packet_size_container">
          <p>
            <label for="packet_size_b">Packet Size:</label>
            <input class="purchase_highlight" type="text" id="packet_size_b" name="packet_size" size="5" /> B <span id="packet_size_kb"></span>
          </p>
          <div id="packet_size_slider" style="margin-left: 10px;margin-right: 10px;"></div>
        </div>
        <div id="randomize_ip_container">
          <p>
            <label for="randomize_ip">Randomize Source IP Every Packet:</label>
            <input class="purchase_highlight" type="checkbox" id="randomize_ip" name="randomize_ip" value="1" />
          </p>
        </div>

        <div id="slowloris_method_container">
          <p>
            <label>HTTP Method:</label>&nbsp;&nbsp;
            <input type="radio" id="slowloris_method_get" name="slowloris_method" value="GET" checked /><label for="slowloris_method_get">GET</label>&nbsp;&nbsp;
            <input type="radio" id="slowloris_method_post" name="slowloris_method" value="POST" /><label for="slowloris_method_post">POST</label>
          </p>
        </div>
        <div id="conn_timeout_container">
          <p>
            <label for="conn_timeout_sec">Connection Timeout:</label>
            <input class="purchase_highlight" type="text" id="conn_timeout_sec" name="conn_timeout" size="3" /> Seconds <span id="conn_timeout_min"></span>
          </p>
          <div id="conn_timeout_slider" style="margin-left: 10px;margin-right: 10px;"></div>
        </div>
        <div id="tcp_timeout_container">
          <p>
            <label for="tcp_timeout_sec">TCP Timeout:</label>
            <input class="purchase_highlight" type="text" id="tcp_timeout_sec" name="tcp_timeout" size="3" /> Seconds <span id="tcp_timeout_min"></span>
          </p>
          <div id="tcp_timeout_slider" style="margin-left: 10px;margin-right: 10px;"></div>
        </div>
        <div id="ssl_container">
          <p>
            <label for="ssl">Use SSL (Overridden when using port 80 or 443):</label>
            <input class="purchase_highlight" type="checkbox" id="ssl" name="ssl" value="1" />
          </p>
        </div>
      </div>


      <p class="centered"><input class="btn btn_large btn_green" type="submit" value="Launch Stress Test" /></p>
    </form>
  </div>
</div>
</body>
</html>
